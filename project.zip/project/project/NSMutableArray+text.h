//
//  NSMutableArray+text.h
//  project
//
//  Created by Sierra 4 on 17/02/17.
//  Copyright © 2017 code-brew. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (text)

@end
