//
//  ViewController.swift
//  project
//
//  Created by Sierra 4 on 17/02/17.
//  Copyright © 2017 code-brew. All rights reserved.
//

import UIKit
import FacebookLogin
import FacebookCore
import FBSDKCoreKit
import FBSDKLoginKit
import FBSDKShareKit

class ViewController: UIViewController {
     var first_name = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClick(_ sender: Any) {
        let loginManager = LoginManager()
        if AccessToken.current == nil {
            
            loginManager.logIn([ .publicProfile,.email,.userFriends ], viewController: self) { loginResult in
                switch loginResult {
                case .failed(let error):
                    print(error)
                case .cancelled:
                    print("User cancelled login.")
                case .success(let grantedPermissions, let declinedPermissions, let accessToken):
                    print("Logged in!")
                    
                    FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name,last_name, picture.type(large),email,updated_time"]).start(completionHandler: { (connection, result, error) -> Void in
                        if (error == nil){
                            
                            if let userDict = result as? NSDictionary {
                                
                                let first_name = userDict["first_name"] as! String
                                let last_Name = userDict["last_name"] as! String
                                let id = userDict["id"] as! String
                                let email = userDict["email"] as! String
                                print(first_name)
                                print(last_Name)
                                print(id)
                                print(email)
                                
                                print(userDict)
                                self.performSegue(withIdentifier: "one", sender: nil)
                                
                            }
                        }
                    })
                }
                
            }
            
        }
        /*else{
        
         LoginManager().logOut()
        }
 */
        }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestViewController : ViewController2 = segue.destination as! ViewController2
        
        DestViewController.LabelText1 = first_name
        //DestViewController.LabelText2 = last_Name
        
        // DestViewController.LabelText3 = email
        
        
    }
    
}

