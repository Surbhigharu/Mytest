//
//  ViewController2.swift
//  project
//
//  Created by Sierra 4 on 17/02/17.
//  Copyright © 2017 code-brew. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
   // @IBOutlet weak var imgview: UIImageView!

    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblSirname: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    var LabelText1 = String()
    
    var LabelText2 = String()
    
    var LabelText3 = String()
    override func viewDidLoad()
    {
        super.viewDidLoad()

        lblName.text = LabelText1
        lblEmail.text = LabelText3
        lblSirname.text = LabelText2
    }

   

}
