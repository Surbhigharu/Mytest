//
//  ViewController4.swift
//  project
//
//  Created by Sierra 4 on 17/02/17.
//  Copyright © 2017 code-brew. All rights reserved.
//

import UIKit
import Google
import GoogleSignIn
class ViewController4: UIViewController, GIDSignInUIDelegate , GIDSignInDelegate
{

    @IBOutlet weak var signinButton: GIDSignInButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        /*var error: NSError?
        GGLContext.sharedInstance().configureWithError(&error)
        if (error != nil)
        {
        print(error)
            return
         
        }

        // Do any additional setup after loading the view.
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().delegate = self
        let signinbutton = GIDSignInButton(frame: CGRect(x:0,y:0,width:100,height:50))
        signinbutton.center = view.center
        view.addSubview(signinbutton)
 */
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().delegate = self
        
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if (error != nil)
        {
            let userId = user.userID
            let idToken = user.authentication.idToken
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            print(error)
            return
        }
        print(user.profile.email)
    }
    func signInWillDispatch(signIn: GIDSignIn!, error: NSError!) {
        //myActivityIndicator.stopAnimating()
    }
    func signIn(signIn: GIDSignIn!,
                presentViewController viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
        print("sign in presented")
    }
    func signIn(signIn: GIDSignIn!,
                dismissViewController viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
        print("sign in dismiss")
    }
    @IBAction func didTapSignOut(sender: AnyObject) {
        GIDSignIn.sharedInstance().signOut()
    }

}
