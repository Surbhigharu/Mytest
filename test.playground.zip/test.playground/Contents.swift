//: Playground - noun: a place where people can play

import UIKit

enum geometricShapes {
 case square
 case rectangle
 case circle
 case sphere
	case cylinder
 }
func squareArea(side:Int)
{
    var area:Int
    area=side*side
    print("squarearea \(area)")
    
}

//print("area is \(squareArea(side:2))")
func squarePerimeter(side:Int)
{
    var perimeter:Int
    perimeter=4*side
    print("squareperimeter \(perimeter)")
    
    
}
//print("perimeter is \(squarePerimeter(side:2))")

func squareVolume(side:Int)
{
    var volume:Int
    volume=side*side*side
    print("square volume \(volume)")
    
}
//print("volume is \(squareVolume(side:2))")

func squareSurfaceArea(side:Int)
{
    var surfacearea:Int
    surfacearea=side*side
    //print(surfacearea)
    print("square surface area  \(surfacearea)")
    
}
//print("surface area is \(squareSurfaceArea(side:2))")


/////////////////////////////////////////////////////////////
//////rectangle////////////

func rectangleArea(length:Int,width:Int)
{
    var area:Int
    area=length*width
    print(area)
    
    
}

//print("area is hjhjhj\(rectangleArea(length:2,width:2))")
func rectanglePerimeter(length:Int,width:Int)
{
    var perimeter:Int
    perimeter=2*(length+width)
    print(perimeter)
    
    
}
//print("perimeter is \(rectanglePerimeter(length:2,width:2))")

func rectangleVolume(side:Int) -> Int
{
    var volume:Int
    volume=side*side*side
    //print(volume)
    return(volume)
    
}
//print("volume is \(rectangleVolume(side:2))")

func rectangleSurfaceArea(side:Int) -> Int
{
    var surfacearea:Int
    surfacearea=side*side
    //print(surfacearea)
    return(surfacearea)
    
}
//print("volume is \(rectangleSurfaceArea(side:2))")
/////////////////////////////////////////////////////////////////////////////////////////////////circle//////////////////////////////////////
func circleArea(radius:Int) -> Int
{
    var area:Int
    area=radius*radius
    //print(area)
    return(area)
    
}

//print("area is \(circleArea(radius:2))")
func circlePerimeter(radius:Float) -> Float
{
    var perimeter:Float
    perimeter = 2 * 3.14 * radius
    //print(perimeter)
    return(perimeter)
    
}
//print("perimeter is \(circlePerimeter(radius:2))")

func circleVolume(side: Int)-> Int
{
    var volume:Int
    volume = side * side * side
    //print(volume)
    return(volume)
    
}
//print("volume is \(circleVolume(side:2))")

func circleSurfaceArea(radius:Int) -> Int
{
    var surfacearea:Int
    surfacearea = radius * radius
    //print(surfacearea)
    return(surfacearea)
    
}
//print("volume is ghgfg\(circleSurfaceArea(radius:2))")
/////////////////////////////////////////////////////////////
/*switch choice {
    print("square")
    squareArea(side:2)
    squarePerimeter(side:2)
    squareVolume(side:2)
    squareSurfaceArea(side:2)
    break
/*case .rectangle:
    squareArea(side:2)
    break
case .circle:
    squareArea(side:2)
    break
case .sphere:
    squareArea(side:2)
    break
case .cylinder:
    squareArea(side:2)
    break*/
default:
    print("Not avaliable")
}*/

//let select=geometricShapes.square
func evaluate(choice:geometricShapes) {
    
    switch choice
    {
    case .square:
        print("square")
        squareArea(side:2)
        squarePerimeter(side:2)
        squareVolume(side:2)
        squareSurfaceArea(side:2)
        break
        /*case .rectangle:
         squareArea(side:2)
         break
         case .circle:
         squareArea(side:2)
         break
         case .sphere:
         squareArea(side:2)
         break
         case .cylinder:
         squareArea(side:2)
         break*/
    default:
        print("Not avaliable")
    }
    
}

print(evaluate(choice:.square))////////SQUARE////////////////





